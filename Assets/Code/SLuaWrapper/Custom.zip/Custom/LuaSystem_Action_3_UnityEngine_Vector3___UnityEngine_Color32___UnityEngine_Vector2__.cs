﻿
using System;
using System.Collections.Generic;
namespace SLua
{
    public partial class LuaDelegation : LuaObject
    {

        static internal void Lua_System_Action_3_UnityEngine_Vector3___UnityEngine_Color32___UnityEngine_Vector2__(LuaFunction ld ,UnityEngine.Vector3[] a1,UnityEngine.Color32[] a2,UnityEngine.Vector2[] a3) {
            IntPtr l = ld.L;
            int error = pushTry(l);

			pushValue(l,a1);
			pushValue(l,a2);
			pushValue(l,a3);
			ld.pcall(3, error);
			LuaDLL.lua_settop(l, error-1);
		}
	}
}
